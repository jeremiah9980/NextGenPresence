# Base agent scaffold
